export const baseURL = "YOUR_BASE_URL";
export const devKey = "YOUR_SECRET_KEY";
