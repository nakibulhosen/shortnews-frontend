//Get BANNER
export const GET_BANNER = "GET_BANNER";

//Insert BANNER
export const INSERT_BANNER = "INSERT_BANNER";

//Update BANNER
export const UPDATE_BANNER = "UPDATE_BANNER";

//Delete BANNER
export const DELETE_BANNER = "DELETE_BANNER";

//Insert Open Dialog
export const OPEN_BANNER_DIALOG = "OPEN_BANNER_DIALOG";

//Close Dialog
export const CLOSE_BANNER_DIALOG = "CLOSE_BANNER_DIALOG";
