//Get CATEGORY
export const GET_CATEGORY = "GET_CATEGORY";

//Insert CATEGORY
export const INSERT_CATEGORY = "INSERT_CATEGORY";

//Update CATEGORY
export const UPDATE_CATEGORY = "UPDATE_CATEGORY";

//Delete CATEGORY
export const DELETE_CATEGORY = "DELETE_CATEGORY";

//Insert Open Dialog
export const OPEN_DIALOG = "OPEN_DIALOG";

//Close Dialog
export const CLOSE_DIALOG = "CLOSE_DIALOG";
