//Get Setting
export const GET_SETTING = "GET_SETTING";

//Update Setting
export const UPDATE_SETTING = "UPDATE_SETTING";
