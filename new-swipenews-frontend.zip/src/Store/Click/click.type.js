//Location Wise Clicks'
export const CLICK_LOCATION = "CLICK_LOCATION";
