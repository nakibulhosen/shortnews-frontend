//Get OwnAd
export const GET_OWN_AD = "GET_OWN_AD";

//Insert ,update , delete OwnAd
export const INSERT_OWN_AD = "INSERT_OWN_AD";
export const UPDATE_OWN_AD = "UPDATE_OWN_AD";
export const DELETE_OWN_AD = "DELETE_OWN_AD";

//Remove OwnAd Remove
export const DELETE_OEN_AD_IMAGE = "DELETE_OEN_AD_IMAGE";

//Toggle OwnAd Show
export const SHOW_OWN_AD = "SHOW_OWN_AD";

//Toggle GoogleAd Show
export const SHOW_GOOGLE_AD = "SHOW_GOOGLE_AD";

//Open Dialog
export const OPEN_OWN_AD_DIALOG = "OPEN_OWN_AD_DIALOG";
export const CLOSE_OWN_AD_DIALOG = "CLOSE_OWN_AD_DIALOG";

//Get GoogleAd
export const GET_GOOGLE_AD = "GET_GOOGLE_AD";
export const UPDATE_GOOGLE_AD = "UPDATE_GOOGLE_AD";

//Toast
export const OPEN_AD_TOAST = "OPEN_AD_TOAST";
export const CLOSE_AD_TOAST = "CLOSE_AD_TOAST";

//Get Data using analysis
export const GET_OWN_AD_BY_TIME = "GET_OWN_AD_BY_TIME";
