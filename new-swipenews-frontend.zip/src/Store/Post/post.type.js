//Dialog
export const OPEN_DIALOG = "OPEN_DIALOG";
export const CLOSE_DIALOG = "CLOSE_DIALOG";

//Insert Post
export const INSERT_POST = "INSERT_POST";
export const UPDATE_POST = "UPDATE_POST";
export const DELETE_POST = "DELETE_POST";

//Toast
export const OPEN_POST_TOAST = "OPEN_POST_TOAST";
export const CLOSE_POST_TOAST = "CLOSE_POST_TOAST";

//Toggle API
export const GET_TOGGLE_API = "GET_TOGGLE_API";
export const TOGGLE_API = "TOGGLE_API";

//Get Post Pagination Wise
export const GET_POST_PAGINATION = "GET_POST_PAGINATION";
