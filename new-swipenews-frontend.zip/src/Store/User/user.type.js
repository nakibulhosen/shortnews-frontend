//Get User
export const GET_USER = "GET_USER";

//Get User Details
export const USER_DETAILS = "USER_DETAILS";

//Get User Pagination Wise
export const GET_USER_PAGINATION = "GET_USER_PAGINATION";

//Search API
export const SEARCH_DATA = "SEARCH_DATA";
